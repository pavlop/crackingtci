import java.util.Arrays;


public class Fast {

    public static void main(String[] args) {
        In in = new In(args[0]);      // input file
        int N = in.readInt();         // number of points N

        // repeatedly read in sites to open and draw resulting system
        Point[] points = new Point[N];

        int i = 0;
        while (!in.isEmpty()) {
            int x = in.readInt();
            int y = in.readInt();
            Point point = new Point(x, y);
            points[i] = point;
            i++;
        }

        Point[] unchangingPoints = new Point[N];

        //copying points to an unchanging array.
        for (int x = 0; x < N; x++)
            unchangingPoints[x] = points[x];

        for (Point p: unchangingPoints) {
            Arrays.sort(points, p.SLOPE_ORDER);
            int end = 0;
            int count = 0;
            int flag = 0;

            for (int x = 1; x < N; x++) {
                if (p.slopeTo(points[x]) == p.slopeTo(points[x-1])) {
                    flag = 1;
                    count++;
                    end = x;
                    continue;
                }

                if(flag == 1)
                    break;
            }

            if (count > 2) {
                int start = end - count;
                StdOut.print(p.toString() + " -> ");
                for(int index = 0; index < count + 1; index++)
                    if(index < count)
                        StdOut.print(points[start + index].toString() + " -> ");
                    else
                        StdOut.println(points[start + index].toString());
            }

        }
    }
}