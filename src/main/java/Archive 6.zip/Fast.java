import java.util.Arrays;

/**
 *
 *
 *
 */
public class Fast {
    public static void main(String[] args) {
        In inputFile = new In(args[0]);
        // How many points do we have in the input file?
        int n = inputFile.readInt();
        Point[] points = new Point[n];
        // Rescale coordinate system for proper visualization.
        //StdDraw.setXscale(0, 32768); StdDraw.setYscale(0, 32768);

        for (int i = 0; !inputFile.isEmpty(); i++) {
            int x = inputFile.readInt();
            int y = inputFile.readInt();
            points[i] = new Point(x, y);
        }
        Arrays.sort(points);

        for (int i = 0; i < points.length; i++) {
            Point origin = points[i];
            Point[] leftPoints = Arrays.copyOfRange(points, i+1, points.length);
            Arrays.sort(leftPoints, origin.SLOPE_ORDER);
            for (int j = i; j < n - 3; j++) {
                double slopeWithJ = origin.slopeTo(points[j]);
                if( slopeWithJ == origin.slopeTo(points[j+1])
                        && slopeWithJ == origin.slopeTo(points[j+2]));
                    StdOut.println(origin + " -> " + points[j] + " -> " + points[j+1] + " -> " + points[j+2]);
            }
        }
    }
}
