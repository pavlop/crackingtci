import java.util.Arrays;

/**
 *
 *
 *
 */
public class Fast {
    public static void main(String[] args) {
        In inputFile = new In(args[0]);
        // How many points do we have in the input file?
        int n = inputFile.readInt();
        Point[] points = new Point[n];
        // Rescale coordinate system for proper visualization.
        //StdDraw.setXscale(0, 32768); StdDraw.setYscale(0, 32768);

        for (int i = 0; !inputFile.isEmpty(); i++) {
            int x = inputFile.readInt();
            int y = inputFile.readInt();
            points[i] = new Point(x, y);
        }

        Arrays.sort(points);
//        System.out.println(Arrays.toString(points));

        for (int i = 0; i < points.length; i++) {
            Point origin = points[i];
            Point[] leftPoints = Arrays.copyOfRange(points, i+1, points.length);
//            System.out.println("left"+Arrays.toString(leftPoints));
            Arrays.sort(leftPoints, origin.SLOPE_ORDER);
            for (int j = 0; j < n - i -1; ) {
                double slopeWithJ = origin.slopeTo(leftPoints[j]);
                int sameSlop = 1;
                StringBuilder result = new StringBuilder();
                result.append(origin + " -> " + leftPoints[j]);
                while ((j + sameSlop < n  - i -1)  && slopeWithJ == origin.slopeTo(leftPoints[j+sameSlop])) {
                    result.append(" -> " + leftPoints[j+sameSlop]);
                    sameSlop++;
                }
                j += sameSlop;
                if(sameSlop >= 3) StdOut.println(result.toString());
            }
        }
    }
}
