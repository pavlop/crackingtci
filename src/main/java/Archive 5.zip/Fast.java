/**
 *
 *
 *
 */
public class Fast {
    public static void main(String[] args) {
        In inputFile = new In(args[0]);
        // How many points do we have in the input file?
        int n = inputFile.readInt();
        Point[] points = new Point[n];
        // Rescale coordinate system for proper visualization.
        StdDraw.setXscale(0, 32768); StdDraw.setYscale(0, 32768);

        for (int i = 0; !inputFile.isEmpty(); i++) {
            int x = inputFile.readInt();
            int y = inputFile.readInt();
            points[i] = new Point(x, y);
        }
    }
}
