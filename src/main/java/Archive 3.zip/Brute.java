public class Brute {
    public static void main(String[] args) {

        int n = 0;

        In inputFile;
        Point[] points;

        inputFile = new In(args[0]);

        // How many points do we have in the input file?
        n = inputFile.readInt();

        // Allocate enough space for them
        points = new Point[n];

        // Rescale coordinate system for proper visualization.
        StdDraw.setXscale(0, 32768); StdDraw.setYscale(0, 32768);

        for (int i = 0; !inputFile.isEmpty(); i++) {
            int x = inputFile.readInt();
            int y = inputFile.readInt();
            points[i] = new Point(x, y);
        }

        for (int l1 = 0; l1 < n; l1++) {
            points[l1].draw();

            for (int l2 = l1 + 1; l2 < n; l2++) {
                if (points[l1].compareTo(points[l2]) >= 0) continue; // first should be smaller then second
                double slopeprFirstTwo = points[l1].slopeTo(points[l2]);

                for (int l3 = l2 + 1; l3 < n; l3++) {
                    if (slopeprFirstTwo != points[l1].slopeTo(points[l3]) || points[l2].compareTo(points[l3]) >= 0) continue;

                    for (int l4 = l3 + 1; l4 < n; l4++) {
                        if (slopeprFirstTwo != points[l1].slopeTo(points[l4]) || points[l3].compareTo(points[l4]) >= 0) continue;
                        points[l1].drawTo(points[l4]);
                        StdOut.println(points[l1] + " -> " + points[l2] + " -> " + points[l3] + " -> " + points[l4]);
                    }
                }
            }
        }

    }
}

//        }
//        for (int l0 = 0; l0 < n; l0++) {
//            p = points[l0];
//            p.draw();
//            for (int l1 = 0; l1 < n; l1++) {
//                if (l1 == l0)
//                    continue;
//                q = points[l1];
//                slopepq = p.slopeTo(q);
//                // To print only the combination of points
//                // that go in ascending order
//                if (p.compareTo(q) > -1)
//                    continue;
//                for (int l2 = 0; l2 < n; l2++) {
//                    if (l2 == l1)
//                        continue;
//                    r = points[l2];
//                    // To print only the combination of points
//                    // that go in ascending order
//                    if (q.compareTo(r) > -1)
//                        continue;
//                    slopepr = p.slopeTo(r);
//                    // if p, q and r aren't collinear, skip the rest.
//                    if (slopepq != slopepr)
//                        continue;
//                    for (int l3 = 0; l3 < n; l3++) {
//                        if (l3 == l2)
//                            continue;
//                        s = points[l3];
//                        // To print only the combination of points
//                        // that go in ascending order
//                        if (r.compareTo(s) > -1)
//                            continue;
//                        slopeps = p.slopeTo(s);
//                        // To print only the combination of points
//                        // that go in ascending order
//                        if (slopepq != slopeps)
//                            continue;
//                        p.drawTo(s);
//                        StdOut.println(p + " -> " + q + " -> " + r + " -> " + s);
//                    }
//                }
//            }
////        }
//    }
//}
